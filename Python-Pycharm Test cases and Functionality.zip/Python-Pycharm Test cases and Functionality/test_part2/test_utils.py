from OurCSCE310Tree import OurCSCE310Tree
import sys
from io import StringIO

def get_actual_output(filepath):
    sys.stdout = StringIO()
    tree = OurCSCE310Tree()
    with open(filepath, "r") as file:
        for line in file:
            tree.insert(int(line.strip()))

    tree.printPreorder()
    print()
    tree.printInorder()
    print()
    tree.printPostorder()
    print()

    output = sys.stdout.getvalue()

    str1, str2, str3 = output.split()

    actual_output_str = [str1, str2, str3]
    actual_output = []
    for str in actual_output_str:
        array = [int(num) for num in str.split(",")]
        actual_output.append(array)

    return actual_output

def get_expected_output(filepath):
    expected_output = []
    with open(filepath, "r") as file:
        for line in file:
            array = [int(num) for num in line.split(",")]
            expected_output.append(array)
    return expected_output

def generate_filepaths():
    input_files = []
    output_files = []
    for i in range(1, 16):
        if i < 10:
            input_filepath = f'../02/part02test0{i}.input'
            output_filepath = f'../02/part02test0{i}.solution'
        else:
            input_filepath = f'../02/part02test{i}.input'
            output_filepath = f'../02/part02test{i}.solution'
        input_files.append(input_filepath)
        output_files.append(output_filepath)
    return input_files, output_files


# input_files, output_files = generate_filepaths()
#
# print(get_expected_output(output_files[0]))

