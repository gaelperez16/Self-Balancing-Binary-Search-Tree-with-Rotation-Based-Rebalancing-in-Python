import unittest
from test_part3.test_utils import get_actual_output, get_expected_output, generate_filepaths


input_files, output_files = generate_filepaths()

class TestPart01(unittest.TestCase):
    def test1(self):
        actual_output = get_actual_output(input_files[0])
        expected_output = get_expected_output(output_files[0])
        self.assertEqual(expected_output, actual_output)

    def test2(self):
        actual_output = get_actual_output(input_files[1])
        expected_output = get_expected_output(output_files[1])
        self.assertEqual(expected_output, actual_output)

    def test3(self):
        actual_output = get_actual_output(input_files[2])
        expected_output = get_expected_output(output_files[2])
        self.assertEqual(expected_output, actual_output)

    def test4(self):
        actual_output = get_actual_output(input_files[3])
        expected_output = get_expected_output(output_files[3])
        self.assertEqual(expected_output, actual_output)

    def test5(self):
        actual_output = get_actual_output(input_files[4])
        expected_output = get_expected_output(output_files[4])
        self.assertEqual(expected_output, actual_output)

    def test6(self):
        actual_output = get_actual_output(input_files[5])
        expected_output = get_expected_output(output_files[5])
        self.assertEqual(expected_output, actual_output)

    def test7(self):
        actual_output = get_actual_output(input_files[6])
        expected_output = get_expected_output(output_files[6])
        self.assertEqual(expected_output, actual_output)

    def test8(self):
        actual_output = get_actual_output(input_files[7])
        expected_output = get_expected_output(output_files[7])
        self.assertEqual(expected_output, actual_output)

    def test9(self):
        actual_output = get_actual_output(input_files[8])
        expected_output = get_expected_output(output_files[8])
        self.assertEqual(expected_output, actual_output)

    def test10(self):
        actual_output = get_actual_output(input_files[9])
        expected_output = get_expected_output(output_files[9])
        self.assertEqual(expected_output, actual_output)

    def test11(self):
        actual_output = get_actual_output(input_files[10])
        expected_output = get_expected_output(output_files[10])
        self.assertEqual(expected_output, actual_output)

    def test12(self):
        actual_output = get_actual_output(input_files[11])
        expected_output = get_expected_output(output_files[11])
        self.assertEqual(expected_output, actual_output)

    def test13(self):
        actual_output = get_actual_output(input_files[12])
        expected_output = get_expected_output(output_files[12])
        self.assertEqual(expected_output, actual_output)

    def test14(self):
        actual_output = get_actual_output(input_files[13])
        expected_output = get_expected_output(output_files[13])
        self.assertEqual(expected_output, actual_output)

    def test15(self):
        actual_output = get_actual_output(input_files[14])
        expected_output = get_expected_output(output_files[14])
        self.assertEqual(expected_output, actual_output)

if __name__ == '__main__':
    unittest.main()
