from OurCSCE310Tree import OurCSCE310Tree
import sys
from io import StringIO

def get_actual_output(filepath):
    sys.stdout = StringIO()
    tree = OurCSCE310Tree()
    delete = False
    with open(filepath, "r") as file:
        for line in file:
            number = int(line.strip())
            if number < 0:
                delete = not delete
            if not delete:
                tree.insert(number)
            else:
                tree.deleteNode(number)

    tree.printInorder()

    output = sys.stdout.getvalue()

    str1 = output.split()


    actual_output = []
    array = [int(num) for num in str1[0].split(",")]
    actual_output.append(array)

    return actual_output

def get_expected_output(filepath):
    expected_output = []
    with open(filepath, "r") as file:
        for line in file:
            array = [int(num) for num in line.split(",")]
            expected_output.append(array)
    return expected_output

def generate_filepaths():
    input_files = []
    output_files = []
    for i in range(1, 16):
        if i < 10:
            input_filepath = f'../03/part03test0{i}.input'
            output_filepath = f'../03/part03test0{i}.solution'
        else:
            input_filepath = f'../03/part03test{i}.input'
            output_filepath = f'../03/part03test{i}.solution'
        input_files.append(input_filepath)
        output_files.append(output_filepath)
    return input_files, output_files


# input_files, output_files = generate_filepaths()
#
# print(get_expected_output(output_files[0]))

