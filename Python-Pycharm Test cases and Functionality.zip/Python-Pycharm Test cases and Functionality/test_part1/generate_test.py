for i in range(0, 15):
    test_case_str = f"""
    def test{i+1}(self):
        actual_output = get_actual_output(input_files[{i}])
        expected_output = get_expected_output(output_files[{i}])
        self.assertEqual(expected_output, actual_output)
    """
    print(test_case_str)